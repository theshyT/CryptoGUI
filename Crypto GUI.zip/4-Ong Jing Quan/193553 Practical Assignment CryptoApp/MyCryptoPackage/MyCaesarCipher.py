b64chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/='


def encrypt(key,plaintext):
    key = int(key)
    plaintext_utf8 = plaintext
    ciphertext_utf8 = ""

    for character in plaintext_utf8:
        if character in b64chars:
            # get the character position
            position = b64chars.find(character)
            position = position + key

            # wrap-around if position >= length of LETTERS
            if position >= len(b64chars):
                position = position - len(b64chars)

            # append encrypted character
            ciphertext_utf8 = ciphertext_utf8 + b64chars[position]

        else:
            # append character without encrypting
            ciphertext_utf8 = ciphertext_utf8 + character

    return ciphertext_utf8


def decrypt(key,ciphertext):
    key = int(key)
    ciphertext_utf8 = ciphertext
    decryptedtext = ""

    for character in ciphertext_utf8:
        if character in b64chars:
            # get the character position
            position = b64chars.find(character)
            position = position - key

            # wrap-around if position >= length of LETTERS
            if position < 0:
                position = position + len(b64chars)

            # append encrypted character
            decryptedtext = decryptedtext + b64chars[position]

        else:
            # append character without encrypting
            decryptedtext = decryptedtext + character

    return decryptedtext









