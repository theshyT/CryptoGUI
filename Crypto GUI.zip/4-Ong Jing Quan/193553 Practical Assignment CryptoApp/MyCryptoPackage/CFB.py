from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad, unpad
from base64 import b64encode, b64decode


def get_fixed_key():
    # use fixed AES key, 256 bits
    return b"01224567890123456789012345678901"


def get_random_key_256():
    """ generate random AES key, keysize = 32*8 = 256 bits"""
    return get_random_bytes(32)


def get_random_key_192():
    """ generate random AES key, keysize = 24*8 = 192 bits"""
    return get_random_bytes(24)


def get_random_key_128():
    """ generate random AES key, keysize = 16*8 = 128 bits"""
    return get_random_bytes(16)


# AES encrypt using CFB and IV, with default padding (PKCS7)
def encrypt(key, plaintext_utf8, ciphertext_file):
    cipher = AES.new(key, AES.MODE_CFB) #Q6
    ciphertext = cipher.encrypt(pad(plaintext_utf8,AES.block_size))
    iv = b64encode(cipher.iv).decode('utf-8')
    ct = b64encode(ciphertext).decode('utf-8')
    # write iv and ciphertext to file
    file_out = open(ciphertext_file, "wb")
    [file_out.write(x) for x in (cipher.iv, ciphertext)]
    file_out.close()

    return ct


# AES decrypt using CFB and IV, with default unpadding (PKCS7)
def decrypt(key, ciphertext_file):
    # read iv and ciphertext from file
    file_in = open(ciphertext_file, "rb")
    iv, ciphertext = [file_in.read(x) for x in (16, -1)]
    file_in.close()

    cipher = AES.new(key, AES.MODE_CFB, iv) #Q6
    decryptedtext_utf = unpad(cipher.decrypt(ciphertext), AES.block_size)

    return decryptedtext_utf


def test():
    plain = "TechTutorialsX!!TechTutorialsX!!"
    key = get_random_key_256()
    ciphertext = encrypt(key, plain.encode("utf-8"),'CFB_ciphertext.bin')
    print(ciphertext)
    decryptedtext = decrypt(key,'CFB_ciphertext.bin').decode('utf-8')
    print(decryptedtext)

