
def encrypt(key, plaintext):

    letters = list("abcdefghijklmnopqrstuvwxyz")
    Text = []
    OTP = []
    for i in range(len(plaintext)):
        Text.append(letters.index(plaintext[i].lower()))
        OTP.append(letters.index(key[i].lower()))

    encrypted = ''
    for i in range(len(Text)):
        encrypted += letters[(Text[i] + OTP[i]) % 26]

    return encrypted


def decrypt(key, ciphertext):

    letters = list("abcdefghijklmnopqrstuvwxyz")
    Text = []
    OTP = []
    for i in range(len(ciphertext)):
        Text.append(letters.index(ciphertext[i].lower()))
        OTP.append(letters.index(key[i].lower()))
    decrypted = ''
    for i in range(len(Text)):
        op = (Text[i] - OTP[i])
        if op < 0:
            y = 26 + op
        else:
            y = op % 26

        decrypted += letters[y]
    return decrypted
