LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'


def encrypt(key, plaintext):
    encrypted = ''
    charsA = LETTERS
    charsB = key

    for char in plaintext:
        if char.upper() in charsA:
            symIndex = charsA.find(char.upper())
            if char.isupper():
                encrypted += charsB[symIndex].upper()
            else:
                encrypted += charsB[symIndex].lower()
        else:
            encrypted += char

    return encrypted


def decrypt(key, ciphertext):
    decrypted = ''
    charsB = LETTERS
    charsA = key

    for char in ciphertext:
        if char.upper() in charsA:
            symIndex = charsA.find(char.upper())
            if char.isupper():
                decrypted += charsB[symIndex].upper()
            else:
                decrypted += charsB[symIndex].lower()
        else:
            decrypted += char

    return decrypted


