from MyCryptoPackage import MyCaesarCipher


def run_test():
    print("TESTING"+"\n")
    key = 3
    plaintext = "Hello World 123"
    ciphertext = MyCaesarCipher.encrypt(key, plaintext)
    decryptedtext =MyCaesarCipher.decrypt(key, ciphertext)
    print("Key:" + str(key))
    print("plaintext: " + plaintext)
    print("ciphertext: " + ciphertext)
    print("decryptedtext: " + decryptedtext + "\n")
    return

run_test()