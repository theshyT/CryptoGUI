from MyCryptoPackage import VernamCipher


def run_test():
    print("TESTING"+"\n")
    key = 'secretsecret'
    plaintext = "secretvernam"
    ciphertext = VernamCipher.encrypt(key, plaintext)
    decryptedtext = VernamCipher.decrypt(key, ciphertext)
    print('key:' + key)
    print("plaintext: " + plaintext)
    print("ciphertext: " + ciphertext)
    print("decryptedtext: " + decryptedtext + "\n")
    return

run_test()
