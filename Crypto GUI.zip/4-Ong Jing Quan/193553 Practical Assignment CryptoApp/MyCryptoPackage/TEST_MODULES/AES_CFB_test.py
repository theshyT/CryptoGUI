from MyCryptoPackage import CFB


def run_test():
    key = CFB.get_random_key_256()
    print("\n")
    print("Key:", key)
    plaintext_string = "Testing AES encrypt and decrypt for CFB."
    ciphertext_file = "CFB_ciphertext.bin"

    # encode plaintext, then encrypt
    ct = CFB.encrypt(key, plaintext_string.encode("utf8"), ciphertext_file)

    # decrypt ciphertext, then decode
    decryptedtext_string = CFB.decrypt(key, ciphertext_file).decode("utf8")
    print("plaintext: " + plaintext_string)
    print("ciphertext: " + ct)
    print("decryptedtext: " + decryptedtext_string)

    return


run_test()