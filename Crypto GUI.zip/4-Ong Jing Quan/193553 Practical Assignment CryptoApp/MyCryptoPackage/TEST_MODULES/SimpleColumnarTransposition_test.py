from MyCryptoPackage import SimpleColumnarTransposition


def run_test():
    print("TESTING"+"\n")
    key = 5
    plaintext = "Hello World 123 Testing for ColumnarTransposition Cipher"
    ciphertext = SimpleColumnarTransposition.encrypt(key, plaintext)
    decryptedtext = SimpleColumnarTransposition.decrypt(key, ciphertext)
    print("Key:" + str(key))
    print("plaintext: " + plaintext)
    print("ciphertext: " + ciphertext)
    print("decryptedtext: " + decryptedtext + "\n")
    return

run_test()
