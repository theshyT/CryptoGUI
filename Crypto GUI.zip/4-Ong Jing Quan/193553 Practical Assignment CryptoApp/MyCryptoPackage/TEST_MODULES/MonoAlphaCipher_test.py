from MyCryptoPackage import MonoAlphaCipher


def run_test():
    print("TESTING"+"\n")
    key = 'CDEFGHIJKLMNOPQRSTUVWXYZAB'
    plaintext = "Hello World 123 Testing for MonoAlpha Cipher"
    ciphertext = MonoAlphaCipher.encrypt(key, plaintext)
    decryptedtext =MonoAlphaCipher.decrypt(key, ciphertext)
    print("Key:" + str(key))
    print("plaintext: " + plaintext)
    print("ciphertext: " + ciphertext)
    print("decryptedtext: " + decryptedtext + "\n")
    return


run_test()
