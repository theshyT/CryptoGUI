from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad, unpad
from base64 import b64encode


def get_fixed_key():
    # use fixed AES key, 256 bits
    return b"01234567890123456789012345678901"


def get_random_key_256():
    """ generate random AES key, keysize = 32*8 = 256 bits"""
    return get_random_bytes(32)


def get_random_key_192():
    """ generate random AES key, keysize = 24*8 = 192 bits"""
    return get_random_bytes(24)


def get_random_key_128():
    """ generate random AES key, keysize = 16*8 = 128 bits"""
    return get_random_bytes(16)


def encrypt(key,plaintext_utf8, ciphertext_file):
    cipher = AES.new(key, AES.MODE_ECB)
    ciphertext = cipher.encrypt(pad(plaintext_utf8,AES.block_size))
    ct = b64encode(ciphertext).decode('utf-8')
    file_out = open(ciphertext_file, "wb")
    [file_out.write(x) for x in (key, ciphertext)]
    file_out.close()

    return ct


def decrypt(key, ciphertext_file):
    file_in = open(ciphertext_file, "rb")
    if len(key) == 16:
        keyz, ciphertext = [file_in.read(x) for x in (16, -1)]
        file_in.close()
        cipher = AES.new(key, AES.MODE_ECB)
        decryptedtext = unpad(cipher.decrypt(ciphertext), AES.block_size)
        return decryptedtext
    elif len(key) == 24:
        keyz, ciphertext = [file_in.read(x) for x in (24, -1)]
        file_in.close()
        cipher = AES.new(key, AES.MODE_ECB)
        decryptedtext = unpad(cipher.decrypt(ciphertext), AES.block_size)
        return decryptedtext
    elif len(key) == 32:
        keyz, ciphertext = [file_in.read(x) for x in (32, -1)]
        file_in.close()
        cipher = AES.new(key, AES.MODE_ECB)
        decryptedtext = unpad(cipher.decrypt(ciphertext), AES.block_size)
        return decryptedtext


def test():
    plain = "iceiceiceicetesticeiceiceicetest"
    key = get_fixed_key()
    print(key)
    ciphertext = encrypt(key, plain.encode("utf-8"),'ECB_ciphertext.bin')
    print(ciphertext)
    decryptedtext = decrypt(key,'ECB_ciphertext.bin').decode('utf-8')
    print(decryptedtext)


