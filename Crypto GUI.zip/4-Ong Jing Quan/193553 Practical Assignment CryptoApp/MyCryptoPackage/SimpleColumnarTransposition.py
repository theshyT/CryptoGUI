import math


def encrypt(key, plaintext):
    key = int(key)
    plaintext = plaintext
    encryptedtxt = [''] * key

    for column in range(key):
        current_index = column
        while current_index < len(plaintext):
            encryptedtxt[column] += plaintext[current_index]
            current_index += key

    return''.join(encryptedtxt)


def decrypt(key, ciphertext):
    key = int(key)
    ciphertext = ciphertext

    num_columns = math.ceil(len(ciphertext) / key)
    num_rows = key
    num_shaded_boxes = (num_columns * num_rows) - len(ciphertext)
    decryptedtxt = [''] * num_columns

    column = row = 0
    for char in ciphertext:
        decryptedtxt[column] += char
        column += 1
        if (column == num_columns
                or (column == num_columns - 1 and row >= num_rows - num_shaded_boxes)):
            column = 0
            row += 1

    return''.join(decryptedtxt)
